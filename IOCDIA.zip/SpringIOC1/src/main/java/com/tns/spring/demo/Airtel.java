package com.tns.spring.demo;

public class Airtel implements Sim {
   
	public void calling()
    {
    System.out.println("calling.......");	
    }
	
    public void data()
    {
    	System.out.println("Searching......");
    }
}
