package com.tns.spring.demo;

public class Jio implements Sim {
    
	public void calling()
    {
    System.out.println("calling JIO.......");	
    }
	
    public void data()
    {
    	System.out.println("Searching JIO......");
    }
}
