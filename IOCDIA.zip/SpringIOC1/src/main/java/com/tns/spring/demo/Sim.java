package com.tns.spring.demo;

public interface Sim {
	void calling();
	void data();

}
