package com.tns.di1;

public class MathCheat {

	public void mathCheat()
	{
		System.out.println("Microxerox cheat is ready for copy.....!");
	}
}
